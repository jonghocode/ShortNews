package com.ShortNews.ShortNews.service;

import com.ShortNews.ShortNews.entity.Member;
import com.ShortNews.ShortNews.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.NoSuchAlgorithmException;
import java.util.Optional;
import java.util.Random;

@Service
public class LoginService {

    @Autowired
    private LoginRepository loginRepository;

    @Autowired
    private SignupService signupService;

    public boolean idCheck(String id) {
        Optional<Member> list = loginRepository.findById(id);
        if(list.isEmpty()){
            return false;
        }else {
            return true;
        }
    }


    // 로그인 성공했다면 세션 설정 해야함, 비밀번호 해시함수 돌려서 확인해야함
    public boolean loginCheck(String id, String pw) throws NoSuchAlgorithmException {
        Optional<Member> list = loginRepository.findById(id);
        if (list.isEmpty()) {
            return false;
        } else {
            String findId = list.get().getId();
            String findPw = list.get().getPw();
            String salt = list.get().getSalt();
            String newPw = signupService.makePw(pw, salt);
            if (id.equals(findId) && newPw.equals(findPw)) {
                return true;
            } else {
                return false;
            }
        }
    }

    public boolean findPassword(String id, String email) {
        Optional<Member> list = loginRepository.findById(id);
        if (list.isEmpty()) {
            return false;
        } else {
            String findId = list.get().getId();
            String findEmail = list.get().getEmail();
            if (id.equals(findId) && email.equals(findEmail)) {
                return true;
            } else {
                return false;
            }
        }
    }

    public String makeCode() {
        Random rnd = new Random();
        return String.format("%06d", rnd.nextInt(1000000));
    }
}