package com.ShortNews.ShortNews.service;

import com.ShortNews.ShortNews.SHA256;
import com.ShortNews.ShortNews.dto.MemberDto;
import com.ShortNews.ShortNews.entity.Member;
import com.ShortNews.ShortNews.entity.Preference;
import com.ShortNews.ShortNews.repository.PreferenceRepository;
import com.ShortNews.ShortNews.repository.SignupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import com.ShortNews.ShortNews.entity.PreferenceKey;

@Service
public class SignupService {

    @Autowired
    private SignupRepository signupRepository;
    @Autowired
    private PreferenceRepository preferenceRepository;
    @Autowired
    private JavaMailSender javaMailSender;


    public boolean idCheck(String id) {
        Optional<Member> memberlist = signupRepository.findById(id);
        if (memberlist.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    public String emailCheck(String email) {
        Optional<Member> memberlist = signupRepository.findByEmail(email);
        Random random = new Random();
        if (memberlist.isEmpty()) {
            String code = String.format("%06d",random.nextInt(1000000));
            sendEmail(email, code);
            return code;
        } else {
            return "";
        }
    }

    public String join(MemberDto memberDto) throws NoSuchAlgorithmException {
        String nickname = memberDto.getNickname();
        Optional<Member> memberlist = signupRepository.findByNickname(nickname);
        if (memberlist.isEmpty()) {
            String salt = makeSalt();
            String pw = makePw(memberDto.getPw(), salt);
            String cre_date = getTime();
            if (nickname.equals("")) {
                nickname = memberDto.getId();
            }
            Member member = memberDto.toEntity("I", salt, pw, nickname, cre_date);
            signupRepository.save(member);
            return member.getId();

        } else {
            return "";
        }
    }

    public void selectCategory(List<Boolean> category, String id) {
        // 카테고리 순서 100(정치), 101(경제), 102(사회), 105(IT/과학), 104(세계), 107(스포츠), 106(연예), 103(생활/문화)
        String[] cate_list = new String[]{"100", "101", "102", "105", "104", "107", "106", "103"};

        for (int i = 0; i < 8; i++) {
            if (category.get(i)) {
                // 값이 true면 cate_list와 mem_id를 DB에 저장
                PreferenceKey pk = new PreferenceKey();
                pk.setCate_id(cate_list[i]);
                pk.setId(id);

                Preference pref = new Preference();
                pref.setPreferenceKey(pk);
                preferenceRepository.save(pref);
            }
        }
    }

    private String getTime() {
        SimpleDateFormat formattype = new SimpleDateFormat("yyyyMMdd");
        return formattype.format(new Date());
    }

    public String makeSalt() {
        int leftLimit = 48, rightLimit = 122, targetStringLength = 8;
        Random random = new Random();
        return random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
    }

    public String makePw(String pw, String member_salt) throws NoSuchAlgorithmException {
        SHA256 sha256 = new SHA256();
        return sha256.encrypt(pw+member_salt);
    }

    public void sendEmail(String email, String code) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setText(code);
        javaMailSender.send(message);
    }
}
