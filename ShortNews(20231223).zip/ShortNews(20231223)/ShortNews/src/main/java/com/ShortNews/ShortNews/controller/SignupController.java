package com.ShortNews.ShortNews.controller;


import com.ShortNews.ShortNews.dto.MemberDto;
import com.ShortNews.ShortNews.service.LoginService;
import com.ShortNews.ShortNews.service.SignupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class SignupController {

    @Autowired
    private SignupService signupService;

    @PostMapping("/signup/idCheck")
    public Map<String, Object> signupIdCheck(@RequestParam(value = "id") String id) {
        Map<String, Object> map = new HashMap<>();
        if (signupService.idCheck(id)) {
            map.put("flag", true);
            map.put("status", HttpStatus.OK);
        } else {
            map.put("flag", false);
            map.put("status", HttpStatus.BAD_REQUEST);
        }
        return map;
    }

    @PostMapping("/signup/emailCheck")
    public Map<String, Object> signupEmailCheck(@RequestParam(value = "email") String email) {
        Map<String, Object> map = new HashMap<>();
        String code = signupService.emailCheck(email);
        if (code.equals("")) {
            map.put("flag", false);
            map.put("status", HttpStatus.BAD_REQUEST);
            map.put("code", null);
        } else {
            map.put("flag", true);
            map.put("code", code);
            map.put("status", HttpStatus.OK);
        }
        return map;
    }

    @PostMapping("/signup/submit")
    public Map<String, Object> signupSubmit(@RequestBody MemberDto memberDto, HttpServletRequest request) throws NoSuchAlgorithmException {
        Map<String, Object> map = new HashMap<>();
        String id = signupService.join(memberDto);
        if (id.equals("")) {
            map.put("flag", false);
            map.put("status", HttpStatus.BAD_REQUEST);
        } else {
            HttpSession session = request.getSession();
            session.setAttribute("id", id);
            map.put("flag", true);
            map.put("status", HttpStatus.OK);
        }
        return map;
    }

    @PostMapping("/signup/selectCategory")
    public Map<String, Object> signupSelectCategory(@RequestParam(value="categorylist") List<Boolean> cate, HttpServletRequest request) {
        Map<String, Object> map = new HashMap<>();
        HttpSession session = request.getSession();
        String id = session.getAttribute("id").toString();
        signupService.selectCategory(cate, id);
        map.put("status", HttpStatus.OK);
        return map;
    }
}