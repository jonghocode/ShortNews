package com.ShortNews.ShortNews.controller;

import com.ShortNews.ShortNews.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

@RestController
public class LoginController {

    @Autowired
    LoginService loginService;

    @PostMapping("/login/idCheck")
    public Map<String, Object> loginIdCheck(@RequestParam(value = "id") String id) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", id);

        if (loginService.idCheck(id)) {
            map.put("flag", true);
            map.put("status", HttpStatus.OK);
        } else {
            map.put("flag", false);
            map.put("status", HttpStatus.BAD_REQUEST);
        }
        return map;
    }

    @PostMapping("/login/password")
    public Map<String, Object> loginPassword(@RequestParam(value = "id") String id, @RequestParam(value = "pw") String pw, HttpServletRequest request) throws NoSuchAlgorithmException {
        Map<String, Object> map = new HashMap<>();

        if (loginService.loginCheck(id, pw)) {
            HttpSession session = request.getSession();
            session.setAttribute("id", id);
            map.put("flag", true);
            map.put("status", HttpStatus.OK);
        } else {
            map.put("flag", false);
            map.put("status", HttpStatus.BAD_REQUEST);
        }
        return map;
    }

    @PostMapping("/login/findPassword")
    public Map<String, Object> loginFindPassword(@RequestParam(value="id") String id, @RequestParam(value="email") String email) {
        Map<String, Object> map = new HashMap<>();
        String code = null;
        if (loginService.findPassword(id, email)) {
            code = loginService.makeCode();
            map.put("flag", true);
            map.put("status", HttpStatus.OK);
        } else {
            map.put("flag", false);
            map.put("status", HttpStatus.BAD_REQUEST);
        }
        map.put("code", code);
        return map;
    }
}