package com.school.ShortNews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShortNewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
