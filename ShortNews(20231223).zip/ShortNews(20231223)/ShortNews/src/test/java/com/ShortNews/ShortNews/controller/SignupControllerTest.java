package com.ShortNews.ShortNews.controller;

import com.ShortNews.ShortNews.dto.MemberDto;
import com.ShortNews.ShortNews.repository.SignupRepository;
import com.ShortNews.ShortNews.service.SignupService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class SignupControllerTest {

    @Autowired
    private SignupService signupService;

    @Autowired
    private SignupRepository signupRepository;

    @Test
    void signupIdCheck() {
        //given
        String id = "1234";

        //when
        boolean flag = signupService.idCheck(id);

        //then
        Assertions.assertThat(flag).isEqualTo(false);
    }

    @Test
    void signupEmailCheck() {
        //given
        String email = "abc@naver.com";

        //when
        String code = signupService.emailCheck(email);

        //then
        Assertions.assertThat(code).isEqualTo("");

    }

    @Test
    void join() throws NoSuchAlgorithmException {
        //given
        MemberDto memberDto = MemberDto.builder().id("5555").pw("123").email("yyyyyyy").nickname("").build();

        //when
        String id = signupService.join(memberDto);

        //then
        Assertions.assertThat(id).isEqualTo("5555");
    }

//    @Test
//    void selectCate() throws NoSuchAlgorithmException {
//        //given
//        MemberDto memberDto = MemberDto.builder().id("7777").pw("123").email("xclvnzv").nickname("").build();
//        String id = signupService.join(memberDto);
//        List<Boolean> list = new ArrayList<>();
//        for (int i = 0; i < 8; i++) {
//            list.add(true);
//        }
//
//        //when
//
//        //then
//
//
//    }
}