package com.ShortNews.ShortNews.controller;


import com.ShortNews.ShortNews.repository.LoginRepository;
import com.ShortNews.ShortNews.service.LoginService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginControllerTest {

    @Autowired
    private LoginService loginService;
    @Autowired
    private LoginRepository loginRepository;


    @Test
    void loginidCheck() {
        //given
        String id = "1234";

        //when
        boolean flag = loginService.idCheck(id);

        //then
        Assertions.assertThat(flag).isEqualTo(true);
    }

    @Test
    void loginCheck() {
        //given
        String id = "1234";
        String pw = "비번";

        //when
        boolean flag = loginService.loginCheck(id, pw);

        //then
        Assertions.assertThat(flag).isEqualTo(true);
    }
}