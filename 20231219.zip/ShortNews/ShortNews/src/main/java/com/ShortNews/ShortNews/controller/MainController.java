package com.ShortNews.ShortNews.controller;

import com.ShortNews.ShortNews.service.MainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {

    @Autowired
    private MainService mainService;

    @PostMapping("/main/select/cate")
    public String mainSelectCate(@RequestParam String category) {
        mainService.selectNews(category);
        return "Main";
    }


}
