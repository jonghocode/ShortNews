package com.ShortNews.ShortNews.service;

import com.ShortNews.ShortNews.SHA256;
import com.ShortNews.ShortNews.entity.Member;
import com.ShortNews.ShortNews.entity.Platform;
import com.ShortNews.ShortNews.entity.Preference;
import com.ShortNews.ShortNews.entity.PreferenceKey;
import com.ShortNews.ShortNews.repository.MemberRepository;
import com.ShortNews.ShortNews.repository.PlatformRepository;
import com.ShortNews.ShortNews.repository.PreferenceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Slf4j
@RequiredArgsConstructor
@Service
public class MemberService {

    private final JavaMailSender javaMailSender;
    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private PlatformRepository platformRepository;
    @Autowired
    private PreferenceRepository preferenceRepository;
    @Autowired
    private EntityManager entityManager;

    private String createMemberId() {
        String str = "select member_id_create.nextval from dual";
        Query query = entityManager.createNativeQuery(str);
        String num = query.getSingleResult().toString();

        SimpleDateFormat formattype = new SimpleDateFormat("yyyyMMdd");
        String now = formattype.format(new Date()); // 현재 시간
        return now+num;
    }

    private String makeSalt() {
        int leftLimit = 48, rightLimit = 122, targetStringLength = 8;
        Random random = new Random();
        return random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
    }

    private String makePw(String pw, String member_salt) throws NoSuchAlgorithmException {
        SHA256 sha256 = new SHA256();
        return sha256.encrypt(pw+member_salt);
    }

    public int login(String email, String pw) throws NoSuchAlgorithmException {
        List<Member> email_list = memberRepository.findByEmail(email);
        if (!email_list.isEmpty()) {
            String origin_pw = email_list.get(0).getPw();
            String salt = email_list.get(0).getSalt();

            String new_pw = makePw(pw, salt);
            if (origin_pw.equals(new_pw)) { // 비밀번호가 맞다면
                return 1;
            }
            else{ // 비밀번호가 틀리다면
                return 0;
            }
        }
        else { // 이메일이 없다면
            return -1;
        }

    }

    public boolean join(Member member, String email, String pw, String nickname, int type, String platid) throws NoSuchAlgorithmException {
        List<Member> email_list = memberRepository.findByEmail(email);
        List<Member> nickname_list = memberRepository.findByNickname(nickname);

        if (email_list.isEmpty() && nickname_list.isEmpty()) { // 이메일 중복체크, 닉네임 중복체크
            String id = createMemberId();
            String member_salt = makeSalt();
            String member_pw = makePw(pw, member_salt);

            member.setMem_id(id);
            member.setNickname(id);
            member.setSalt(member_salt);
            member.setPw(member_pw);
            if (type == 0) {
                member.setEmail(email);
            }
            else {
                member.setEmail(platid);
            }
            if (nickname.equals("")) {
                member.setNickname(id);
            } else {
                member.setNickname(nickname);
            }

            memberRepository.save(member);

            Platform platform = new Platform();
            platform.setMem_id(id);

            if (type == 1) {
                platform.setKakao(id);
            } else if (type == 2) {
                platform.setNaver(id);
            } else if (type == 3) {
                platform.setGoogle(id);
            }

            platformRepository.save(platform);
            return true;
        }
        else if (!email_list.isEmpty()) {
            throw new IllegalArgumentException("이메일이 중복됩니다.");
        } else {
            throw new IllegalArgumentException("닉네임이 중복됩니다.");
        }

    }

    public void joinCate(String id, String[] categories) {
        Preference preference = new Preference();

        for (String num : categories) {
            PreferenceKey preferenceKey = new PreferenceKey();
            preferenceKey.setCate_id(num);
            preferenceKey.setMem_id(id);
            preference.setPreferenceKey(preferenceKey);
            preferenceRepository.save(preference);
        }
    }

    public boolean updatePassword(String email, String pw) throws NoSuchAlgorithmException {
        String member_salt = makeSalt();
        String member_pw = makePw(pw, member_salt);

        memberRepository.updateSalt(member_salt, email);
        memberRepository.updatePw(email, member_pw);

        return true;
    }

    public void sendEmail(String email, HttpServletRequest request, String msg) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        // msg가 코드면 코드, url이면 url 전송
        message.setText(msg);

        HttpSession session = request.getSession();
        session.setAttribute("email", email);
        javaMailSender.send(message);
    }
}