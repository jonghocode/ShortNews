package com.ShortNews.ShortNews.controller;

import com.ShortNews.ShortNews.entity.Member;
import com.ShortNews.ShortNews.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

@Controller
public class CreateController { //컨트롤러 -> 서비스 -> 리포지토리
    private String code;
    @Autowired
    private MemberService memberService;

    @PostMapping("/create")
    public String create() {
        return "Create";
    }


    @PostMapping("/create/check")
    public String createCheck(String email, String nickname, String pw, HttpServletRequest request) throws NoSuchAlgorithmException {
        Member member = new Member();

        boolean state = memberService.join(member, email, pw, nickname, 0, "0");
        if (state) {
            HttpSession session = request.getSession();
            session.setAttribute("id", member.getMem_id());
            return "SelectCategory";
        } else {
            return "Create";
        }
    }

    @PostMapping("/select/cate")
    public String selectCate(@RequestParam("check") String[] categories, HttpServletRequest request) {
        HttpSession session = request.getSession();
        String id = session.getAttribute("id").toString();
        memberService.joinCate(id, categories);
        return "Main";
    }

    @PostMapping("select/cate/continue")
    public String selectCateContinue() {
        return "Main";
    }

    Random rnd = new Random();
    @PostMapping("/email/code")
    public String emailSendCode(String email, HttpServletRequest request) {
        code = String.format("%06d", rnd.nextInt(1000000));
        System.out.println(email + ", " + code +", " + request);
        memberService.sendEmail(email, request, code);
        return "Create";
    }

    @PostMapping("/email/certificate")
    public String emailCertificate(String email, HttpServletRequest request, String UserCode) {
        System.out.println(code + ", " + UserCode);
        if (UserCode.equals(code)) {
            System.out.println("인증됨");
            return "Create";
        } else {
            System.out.println("인증안됨");
            return "Create";
        }
    }
}
