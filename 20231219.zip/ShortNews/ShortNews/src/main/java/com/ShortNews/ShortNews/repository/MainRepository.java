package com.ShortNews.ShortNews.repository;

import com.ShortNews.ShortNews.entity.Member;
import com.ShortNews.ShortNews.entity.News;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface MainRepository extends JpaRepository<News, String> {

    @Query("select title from News n where n.cate_id= :cate_id and news_id like :today% order by to_number(news_id) desc")
    public List<String> findByTitle(@Param("cate_id") String cate_id, @Param("today") String today);

}
