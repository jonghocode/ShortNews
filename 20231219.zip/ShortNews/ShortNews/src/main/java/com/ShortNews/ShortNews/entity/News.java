package com.ShortNews.ShortNews.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class News {
    @Id
    private String news_id;
    private String cate_id;
    private String title;
    private String content;
    private Integer views;
    private String link;
}
