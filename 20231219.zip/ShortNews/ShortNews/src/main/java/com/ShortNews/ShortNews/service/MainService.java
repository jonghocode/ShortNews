package com.ShortNews.ShortNews.service;

import com.ShortNews.ShortNews.repository.MainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class MainService {


    @Autowired
    private MainRepository mainRepository;

    public void selectNews(String num) { // 메인에 처음 들어왔을 때
        SimpleDateFormat formattype = new SimpleDateFormat("yyyyMMdd");
        String now = formattype.format(new Date()); // 현재 시간
        List <String> list = mainRepository.findByTitle(num, now);
        for (String title : list) {
            System.out.println("title : " + title);
        }
    }
}