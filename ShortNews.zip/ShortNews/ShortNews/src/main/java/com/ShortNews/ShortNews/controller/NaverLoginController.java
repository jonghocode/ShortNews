package com.ShortNews.ShortNews.controller;
import com.ShortNews.ShortNews.entity.Member;
import com.ShortNews.ShortNews.service.MemberService;
import com.ShortNews.ShortNews.service.OauthService;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequiredArgsConstructor
public class NaverLoginController {
    @Autowired
    private MemberService memberService;
    @Autowired
    private OauthService oauthService;

    @RequestMapping("/naver/login")
    public String callback(HttpServletRequest request) throws Exception {
        Member member = new Member();
        Boolean state = oauthService.getNaverInfo(member, request.getParameter("code"));
        if (state) {
            HttpSession session = request.getSession();
            session.setAttribute("id", member.getMem_id());
            return "SelectCategory";
        }
        else {
            return "NaverLogin";
        }
    }

}
