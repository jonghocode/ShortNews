package com.ShortNews.ShortNews.controller;

import com.ShortNews.ShortNews.entity.Member;
import com.ShortNews.ShortNews.service.OauthService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class KakaoLoginController {

    @Autowired
    private OauthService oauthService;

    @RequestMapping("/kakao/login")
    public String kakaoCallback(@RequestParam String code, HttpServletRequest request) {
        Member member = new Member();
        boolean state = oauthService.getKakaoAccessToken(member, code);
        if (state) {
            HttpSession session = request.getSession();
            session.setAttribute("id", member.getMem_id());
            return "SelectCategory";
        }
        else {
            return "KakaoLogin";
        }
    }



}
